from brain_games.general_functions import start_game
from brain_games.games import brain_even


def main():
    start_game(brain_even)


if __name__ == '__main__':
    main()
